﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PrarthanaLampShades.Models;

namespace PrarthanaLampShades.Data
{
    public class PrarthanaLampShadesContext : DbContext
    {
        public PrarthanaLampShadesContext (DbContextOptions<PrarthanaLampShadesContext> options)
            : base(options)
        {
        }

        public DbSet<PrarthanaLampShades.Models.LampShades> LampShades { get; set; }
    }
}

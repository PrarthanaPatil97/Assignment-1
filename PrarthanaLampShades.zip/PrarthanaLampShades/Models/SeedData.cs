﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PrarthanaLampShades.Models
{
    public class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new PrarthanaLampShadesContext(
                serviceProvider.GetRequiredService<
                    DbContextOptions<LampShadesContext>>()))
            {
                // Look for any lampshades.
                if (context.LampShades.Any())
                {
                    return;   // DB has been seeded
                }

                context.LampShades.AddRange(
                    new LampShades
                    {
                        Title = "When Harry Met Sally",
                        Color = "Romantic Comedy",
                        Shape = "round"
                        Price = 7.99M,
                    },

                    new LampShades
                    {
                        Title = "When Harry Met Sally",
                        Color = "Romantic Comedy",
                        Shape = "round"
                        Price = 7.99M,
                    },

                    new LampShades
                    {
                        Title = "When Harry Met Sally",
                        Color = "Romantic Comedy",
                        Shape = "round"
                        Price = 7.99M,
                    },

                    new LampShades
                    {
                        Title = "When Harry Met Sally",
                        Color = "Romantic Comedy",
                        Shape = "round"
                        Price = 7.99M,
                    }
                );
                context.SaveChanges();
            }
        }
    }
}
}
